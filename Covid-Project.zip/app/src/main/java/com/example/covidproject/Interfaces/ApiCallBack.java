package com.example.covidproject.Interfaces;

public interface ApiCallBack
{

      void onCovidResult(String response,int Code,int DataType);

}
