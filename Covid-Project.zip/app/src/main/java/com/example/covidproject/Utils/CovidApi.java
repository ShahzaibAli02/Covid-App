package com.example.covidproject.Utils;

import android.app.Activity;
import android.content.Context;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.covidproject.Interfaces.ApiCallBack;
import com.google.gson.JsonObject;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import okhttp3.MediaType;
import okhttp3.OkHttp;
import okhttp3.OkHttpClient;
import okhttp3.RequestBody;

public class CovidApi
{


    RequestQueue queue;

    ApiCallBack staticsResult;
    Context mContext;
    public  CovidApi(Context context, ApiCallBack staticsResult)
    {
        queue = Volley.newRequestQueue(context);
        this.staticsResult=staticsResult;
        mContext=context;
    }


    public   void getData(String URL,int DATA_CODE)
    {

        StringRequest stringRequest = new StringRequest(Request.Method.GET, URL,
                response -> {
                    staticsResult.onCovidResult(response, Constants.SUCCESS_CODE, DATA_CODE);
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        staticsResult.onCovidResult(null, Constants.FAIL_CODE, DATA_CODE);
                    }
                }) { //no semicolon or coma
            @Override
            public Map<String, String> getHeaders() throws AuthFailureError
            {
                Map<String, String> params = new HashMap<String, String>();
                if(URL.equals(Constants.COVID_URL_NEWS))
                         params.put("User-Agent" , "Mozilla/5.0");
                return params;
            }
        };;
        queue.add(stringRequest);
    }

    public   void getStatistics(int DATA_CODE)
    {

        OkHttpClient client = new OkHttpClient();

        new Thread()
        {
            @Override
            public void run()
            {
                super.run();
                try
                {
                    okhttp3.Request request = new    okhttp3.Request.Builder()
                            .url(Constants.COVID_URL_STATISTICS)
                            .build();



                    okhttp3.Response response = client.newCall(request).execute();
                    String Response=response.body().string();


                    ((Activity)mContext).runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            staticsResult.onCovidResult(Response, Constants.SUCCESS_CODE, DATA_CODE);
                        }
                    });

                }
                catch (Exception e)
                {
                    staticsResult.onCovidResult(null, Constants.FAIL_CODE, DATA_CODE);
                    ((Activity)mContext).runOnUiThread(new Runnable() {
                        @Override
                        public void run() {

                            Toast.makeText(mContext,"ERROR :"+e.getMessage(),Toast.LENGTH_LONG).show();

                        }
                    });
                }

            }
        }.start();

    }



}
